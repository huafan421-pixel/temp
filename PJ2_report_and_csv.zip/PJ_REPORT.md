# 小学数学应用题自动解题实验报告

## 1. 任务理解与实验要求

本次 PJ 对应“小学数学应用题自动解题”任务，输入为小学 1-6 年级数学应用题文本，输出为不带单位的数字答案。数据集中 `train.json` 包含 11999 条训练样本，`test.json` 包含 8000 条测试样本，提交文件为两列 CSV：`id` 表示测试题编号，`ret` 表示预测答案。平台评测指标为准确率，即预测值与标准答案一致的样本数占测试集总样本数的比例。

根据课程说明，本项目需要在比赛平台提交预测 CSV，并在 elearning 提交最好排名与分数截图、CSV 文件；最终还需要提交代码和约 4 页方案报告。方案限制包括：用于最终输出结果的推理模型规模不超过 0.5B，推荐使用 Qwen；数据构建和增强只允许基于训练数据完成，不使用测试集答案。基于这些要求，本实验围绕 Qwen2.5-0.5B-Instruct 设计了 Prompt/CoT、数据构建 + LoRA SFT、规则模板混合三个方向，并以平台分数作为最终比较依据。

## 2. 方法设计

### 2.1 Prompt 与 CoT 推理

第一类方法不更新模型参数，直接使用 Qwen2.5-0.5B-Instruct 对测试题进行推理。实现脚本为 `qwen_prompt_infer.py`，主要包含三种策略：

- Direct Prompt：要求模型直接输出最终数字答案。
- Zero-shot CoT：要求模型先简要推理，再用“最终答案：数字”的格式输出。
- Few-shot CoT：在提示词中加入若干带解题步骤的示例，引导模型按“分析题意、列式计算、输出最终答案”的格式作答。

由于平台只接受数字答案，推理脚本会对模型输出做后处理：优先抽取“最终答案”后的数字，若格式不规范，则回退抽取输出中的最后一个数值。所有生成的 CSV 都会进行行数、空答案和格式校验，避免无效提交。

### 2.2 数据构建与 LoRA SFT

第二类方法是基于训练集构造新的监督数据，再对 Qwen2.5-0.5B-Instruct 进行 LoRA 微调。数据构建包括两部分：

1. `augment_train.py`：从训练集中抽取高频模板，替换数字生成同结构新题，形成 `train_augmented.json`。该文件包含原始训练样本和 2000 条合成样本，用于提升模型对基础四则、平均分配、倍数关系、照这样计算等题型的拟合能力。
2. `build_cot_data.py`：为部分训练题构造带步骤的 `train_cot.json`。对于规则能解析的题目生成明确计算步骤，对于更复杂题目生成保守的解题格式，使模型学习“步骤 + 最终答案”的输出风格。

训练脚本为 `qwen_lora_sft.py`，推理脚本为 `qwen_lora_infer.py`。本地使用 RTX 4060 Laptop GPU，采用 bf16、LoRA、batch size 2、gradient accumulation 8 的设置进行训练。分别尝试了直接答案 SFT 和 CoT 答案 SFT 两个版本，并提交平台评测。

### 2.3 规则模板求解与混合后处理

第三类方法是规则模板求解器。小学数学应用题中存在一部分结构明确、计算规则稳定的题型，例如：

- “至少需要几辆车/几条船”的向上取整问题；
- “最多可以买几个/最多能做几根”的向下取整问题；
- 正方形边长、周长、面积等几何公式题；
- “照这样计算”的同速率、同单价、同效率问题；
- 训练集中题面完全重复、答案一致的题目。

这些题型由 `improved_rule_hybrid.py` 和 `build_final_hybrid.py` 处理。最终方案以 few-shot CoT 的输出为基础，只在规则非常高置信或训练集题面记忆一致时覆盖原答案。这样可以保留大模型在复杂题上的泛化能力，同时修正常见的算术错误和格式错误。生成的最终提交文件为 `submit_fewshot_improved_rule_hybrid_v6_memory.csv`，同时生成了一个更保守的 `submit_fewshot_improved_rule_hybrid_v6_curated.csv`；两者在平台上得分相同。

## 3. 实验设置与结果

实验环境为 Windows + Python 虚拟环境，本地 GPU 为 RTX 4060 Laptop。模型均使用 Qwen2.5-0.5B-Instruct 或其 LoRA 适配器，满足 0.5B 规模限制。所有提交 CSV 均包含 8000 行测试样本，且无空答案。

平台公开评测结果如下：

| 方法 | 提交文件 | 平台分数 | 约正确题数 |
| --- | --- | ---: | ---: |
| Direct Prompt | `submit_prompt_direct.csv` | 0.057500 | 460 |
| CoT LoRA SFT | `submit_cot_sft.csv` | 0.111875 | 895 |
| 数据增强 LoRA SFT | `submit_aug_sft.csv` | 0.133000 | 1064 |
| Few-shot CoT | `submit_prompt_fewshot_cot.csv` | 0.182125 | 1457 |
| Few-shot CoT + 规则/记忆混合 | `submit_fewshot_improved_rule_hybrid_v6_memory.csv` | **0.194625** | **1557** |

从结果看，few-shot CoT 是单一模型推理中表现最好的方案，相比 direct prompt 有明显提升，说明在数学应用题中显式推理步骤对 0.5B 模型仍然有帮助。LoRA SFT 两个版本低于 few-shot CoT，主要原因可能是训练轮数、数据质量和模型规模受限；部分训练答案存在噪声，且合成题模板覆盖范围有限，导致模型对真实测试题的泛化不足。最终混合方案在 few-shot CoT 基础上净提升 0.0125，即约多答对 100 道题，说明规则后处理能有效修正常见算术模板题。

## 4. 结果分析

Direct Prompt 分数最低，主要问题是模型经常没有稳定执行多步计算，或者输出解释性文字导致答案抽取困难。Zero-shot / few-shot CoT 能提升模型的步骤意识，其中 few-shot CoT 通过示例约束了输出格式，因此在本任务中更稳定。

LoRA SFT 的提升不如预期。一方面，0.5B 模型容量较小，面对小学应用题中大量隐含关系和单位换算时容易混淆；另一方面，训练集本身存在一定噪声，合成数据虽然增加了样本量，但模板较集中，可能放大了简单模式而没有覆盖足够多的真实题型。CoT SFT 的平台分数低于数据增强 SFT，也说明简单模板化步骤并不一定能直接提升最终答案准确率。

规则混合方案的优势在于可解释、稳定，并且对“取整、几何公式、同速率计算、训练集中重复题”等题型很有效。例如 few-shot CoT 容易把“至少需要几辆车”算成普通除法小数或错误整数，而规则可以明确执行 `ceil`；又如“照这样的速度/效率”题，规则可以直接列比例式计算。该方法的局限也很明显：测试题型非常多样，宽泛规则容易误伤，因此最终只启用高置信模板。平台分数的提升幅度有限，但属于低风险增益。

## 5. 复现方式

Prompt/CoT 推理：

```powershell
.\.venv\Scripts\python.exe qwen_prompt_infer.py `
  --test test.json `
  --output submit_prompt_fewshot_cot.csv `
  --strategy few_shot_cot `
  --max-new-tokens 160 `
  --bf16
```

数据增强 SFT：

```powershell
.\.venv\Scripts\python.exe augment_train.py --train train.json --output train_augmented.json --n 2000
.\.venv\Scripts\python.exe qwen_lora_sft.py `
  --train train_augmented.json `
  --output-dir output/qwen_aug_sft `
  --epochs 3 `
  --batch-size 2 `
  --grad-accum 8 `
  --bf16
.\.venv\Scripts\python.exe qwen_lora_infer.py `
  --adapter output/qwen_aug_sft/final `
  --output submit_aug_sft.csv `
  --mode direct `
  --bf16
```

最终混合提交：

```powershell
.\.venv\Scripts\python.exe improved_rule_hybrid.py submit `
  --test test.json `
  --baseline submit_prompt_fewshot_cot.csv `
  --output submit_fewshot_improved_rule_hybrid_v5.csv
.\.venv\Scripts\python.exe build_final_hybrid.py `
  --baseline submit_fewshot_improved_rule_hybrid_v5.csv `
  --output submit_fewshot_improved_rule_hybrid_v6_memory.csv
```

## 6. 总结

本实验完成了三类方案：Prompt/CoT 推理、数据构建 + LoRA SFT、规则模板混合。最终最优提交为 `submit_fewshot_improved_rule_hybrid_v6_memory.csv`，平台分数为 0.194625。虽然该分数距离更高排名仍有差距，但实验验证了 few-shot CoT 对小模型数学推理的提升作用，也证明了高置信规则后处理可以在不增加模型规模的情况下带来稳定增益。后续如果继续优化，优先方向应是构造更高质量的 CoT 数据、改进训练集噪声处理、扩大可验证规则覆盖范围，并尝试用偏好优化方法增强模型对正确推理路径的选择能力。
